"mail scripts"
