# -*- test-case-name: twisted.cred.test -*-
# Copyright (c) Twisted Matrix Laboratories.
# See LICENSE for details.

"""
Unit tests for C{twisted.cred}.
"""
