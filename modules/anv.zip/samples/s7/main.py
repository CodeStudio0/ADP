from kivy.app import App
from kivy.uix.image import Image
from android.permissions import request_permissions, check_permission, Permission
import cv2
from AnvPy import Camera
# importing built-in module

class CameraApp(App):
    def cam_update(self, frame):
        # Camera triggers cam_update function when a new texture is availabl
        frame = cv2.Canny(frame, 50, 150)
        return frame

    def build(self):
        if not check_permission('android.permission.CAMERA'):
            request_permissions([Permission.CAMERA])
            return Label(text="Restart app after providing camera permission")
        self.cam = Camera(play=True, allow_stretch=True, keep_ratio=True)
        return self.cam

if __name__ == "__main__":
    CameraApp().run()
























