from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.label import Label
from kivy.uix.image import Image
from android.permissions import request_permissions,check_permission,Permission
import cv2
from AnvPy import Camera, anv
# importing built-in module
class CameraApp(App):
    def cam_update(self, frame):
	# ADPCamera triggers cam_update function when a new texture is available
        if self.front:
            self.cam.index = 1
        else:
            self.cam.index = 0
        if self.edge:
            frame = cv2.Canny(frame, 50, 150)
        if self.invert:
            frame = cv2.bitwise_not(frame)
        if self.gray:
            frame = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        return frame

    def build(self):
        self.invert = False
        self.gray = False
        self.front = False
        self.edge = False
        box = BoxLayout(orientation='vertical')
        if not check_permission('android.permission.CAMERA'):
            request_permissions([Permission.CAMERA])
            return Label(text="Restart app after providing camera permission")
        self.cam = Camera(play=True,allow_stretch=True,keep_ratio=True)
        # Using ADPCamera class to get camera stream
        tb = ToggleButton(text='Invert color', size_hint_y=None, height='48dp')
        tb.bind(on_press=self.inv)
        gr = ToggleButton(text='Grayscale', size_hint_y=None, height='48dp')
        gr.bind(on_press=self.gry)
        md = ToggleButton(text='Front Camera', size_hint_y=None, height='48dp')
        md.bind(on_press=self.mode)
        cn = ToggleButton(text="Edge Detection",size_hint_y=None, height='48dp')
        cn.bind(on_press=self.canny)
        box.add_widget(self.cam)
        box.add_widget(tb)
        box.add_widget(gr)
        box.add_widget(md)
        box.add_widget(cn)
        return box

    def inv(self, instance):
        if instance.state == 'down':
            self.invert = True
            instance.text = 'Normal color'
        else:
            self.invert = False
            instance.text = 'Invert color'

    def gry(self, instance):
        if instance.state == 'down':
            self.gray = True
            instance.text = 'No Grayscale'
        else:
            self.gray = False
            instance.text = 'Grayscale'

    def mode(self, instance):
        if instance.state == 'down':
            self.front = True
            instance.text = 'Back Camera'
        else:
            self.front = False
            instance.text = 'Front Camera'

    def canny(self, instance):
        if instance.state == 'down':
            self.edge = True
            instance.text = 'No Edge Detection'
        else:
            self.edge = False
            instance.text = 'Edge Detection'

if __name__ == "__main__":
	CameraApp().run()
























