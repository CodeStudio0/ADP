import AnvWeb as web
from kivymd.toast import toast
from kivy.clock import Clock
import cv2, statusbar


statusbar.set_color("#ffffff")
def detect():
    frame = cv2.imread("dev.jpeg")
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 255, 0), 2)
        roi_gray = gray[y:y + h, x:x + w]
        roi_color = frame[y:y + h, x:x + w]
    cv2.imwrite("new.jpg", frame)
    statusbar.set_color("#282a36")
    web.exc("$('img').src='new.jpg';document.body.style.background='#282a36';")
    toast("Face detected")


web.func(detect)
web.run()








































































