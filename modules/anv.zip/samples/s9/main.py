from AnvAds import AdMob
from kivy.lang import Builder
from kivymd.app import MDApp
from kivymd.toast import toast

KV = '''
MDScreen:
    MDRaisedButton:
        text: "Show Rewarded Ad"
        md_bg_color: "#3f48cc"
        text_color: "white"
        pos_hint: {"center_x": .5, "center_y": .5}
        on_press: app.showRewardedAd()
'''


class MainApp(MDApp):
    def success(self):
        toast("Ad seen")
    
    def showRewardedAd(self):
        if not self.app.showRewardedAd():
            toast("Ad not loaded")
        else:
            self.app.loadRewardedAd(self.rewarded_ad_unit)
    
    def showInterstitialAd(self):
        if not self.app.showInterstitialAd():
            toast("Ad not loaded")
        else:
            self.app.loadInterstitialAd(self.interstitial_ad_unit)

    def build(self):
        self.app_id = "ca-app-pub-3940256099942544~3347511713"
        self.rewarded_ad_unit = "ca-app-pub-3940256099942544/5224354917"
        self.interstitial_ad_unit = "ca-app-pub-3940256099942544/1033173712"
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Orange"
        self.app = AdMob(self.rewarded_ad_unit)
        self.app.loadRewardedAd(self.rewarded_ad_unit)
        #self.app.loadInterstitialAd(self.interstitial_ad_unit)
        return Builder.load_string(KV)


MainApp().run()
























