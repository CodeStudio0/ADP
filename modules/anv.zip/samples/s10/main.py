from kivy.app import App
from kivy.uix.label import Label
import plotly.graph_objects as go
from kivy.core.window import Window
import sys
import pandas as pd

class MainApp(App):
    def back(self, window, key, *args):
        if key == 27:
            sys.exit(0)
    def build(self):
        Window.bind(on_keyboard=self.back)
        z_data = pd.read_csv('mt_bruno_elevation.csv')
        fig = go.Figure(data=[go.Surface(z=z_data.values)])

        fig.update_layout(title=dict(text='Mt Bruno Elevation'), autosize=False,
                  width=500, height=500,
                  margin=dict(l=65, r=50, b=65, t=90))
        # show the image in a screen
        fig.show()
        return Label(text="")

MainApp().run()
























