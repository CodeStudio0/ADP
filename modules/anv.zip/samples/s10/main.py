import AnvWeb as web

def data(val):
    web.exc("alert('" + val + "')")
    print(val)


web.func(data)
web.run()
























