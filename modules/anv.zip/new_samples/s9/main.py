from web import WebApp

app = WebApp("index.html")
def data(val):
    app.exec("alert('" + val + "')")
    print(val)


app.add(data)
app.run()
























