from kivy.app import App
from kivy.uix.label import Label
import pandas as pd
from kivy.core.window import Window
import matplotlib.pyplot as plt
from core import anv 
import sys, core

class MainApp(App):
    def back(self, window, key, *args):
        if key == 27:
            sys.exit(0)
    def build(self):
        Window.bind(on_keyboard=self.back)
        core.setOrientation("landscape")
        plt.style.use("dark_background")
        for param in ['text.color', 'axes.labelcolor', 'xtick.color', 'ytick.color']:
            plt.rcParams[param] = '0.9'  
        for param in ['figure.facecolor', 'axes.facecolor', 'savefig.facecolor']:
            plt.rcParams[param] = '#212946'  
        colors = ['#08F7FE', '#FE53BB',  '#F5D300',  '#00ff41']
        df = pd.DataFrame({'A': [1, 3, 9, 5, 2, 1, 1],
                           'B': [4, 5, 5, 7, 9, 8, 6]})
        fig, ax = plt.subplots()
        df.plot(marker='o', color=colors, ax=ax)
        n_shades = 10
        diff_linewidth = 1.05
        alpha_value = 0.3 / n_shades
        for n in range(1, n_shades+1):
            df.plot(marker='o',
                    linewidth=2+(diff_linewidth*n),
                    alpha=alpha_value,
                    legend=False,
                    ax=ax,
                    color=colors)
        for column, color in zip(df, colors):
            ax.fill_between(x=df.index,
                            y1=df[column].values,
                            y2=[0] * len(df),
                            color=color,
                            alpha=0.1)
        ax.grid(color='#2A3459')
        ax.set_xlim([ax.get_xlim()[0] - 0.2, ax.get_xlim()[1] + 0.2])  # to not have the markers cut off
        ax.set_ylim(0)
        # show the image in a screen
        anv.pltshow(plt)
        return Label(text="")

MainApp().run()























