from web import WebApp
import core
import cv2


core.statusbarColor("#ffffff")
core.navigationbarColor("#ffffff")
app = WebApp("index.html")
def detect():
    global app
    frame = cv2.imread("dev.jpeg")
    face_cascade = cv2.CascadeClassifier('haarcascade_frontalface_default.xml')
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    faces = face_cascade.detectMultiScale(gray, 1.3, 5)
    for (x, y, w, h) in faces:
        cv2.rectangle(frame, (x, y), (x + w, y + h), (255, 255, 0), 2)
        roi_gray = gray[y:y + h, x:x + w]
        roi_color = frame[y:y + h, x:x + w]
    cv2.imwrite("new.jpg", frame)
    core.statusbarColor("#282a36")
    core.navigationbarColor("#282a36")  
    app.exec("$('img').src='new.jpg';document.body.style.background='#282a36';")
    core.toast("Face detected")


app.add(detect)
app.run()








































































