from kivy.app import App
from kivy.uix.image import Image
from android.permissions import request_permissions, check_permission, Permission
import cv2, sys
from kivy.core.window import Window
from core import Camera
# importing built-in module

class CameraApp(App):
    def cam_update(self, frame):
        # Camera triggers cam_update function when a new texture is availabl
        frame = cv2.Canny(frame, 50, 150)
        return frame

    def build(self):
        Window.bind(on_keyboard=self.back)
        if not check_permission('android.permission.CAMERA'):
            request_permissions([Permission.CAMERA])
            return Label(text="Restart app after providing camera permission")
        self.cam = Camera(play=True, allow_stretch=True, keep_ratio=True)
        return self.cam
    
    def back(self, window, key, *args):
        if key == 27:
            sys.exit(0)

if __name__ == "__main__":
    CameraApp().run()
























