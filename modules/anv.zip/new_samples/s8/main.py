from crysta import Root, Button, FlexLayout
from ads import AdMob
import core

app = AdMob("ca-app-pub-1510165203415209~8964838105")    # Provide AdMob app id

def on_load():    # if val is 1, then ad loaded
	core.alert("INFO","Ad Loaded")

def on_success(*args):
	core.alert("HOO!","Ad Seen")    # Ad seen

def loadAd():
    core.toast("Loading Ads")
    app.loadInterstitialAd("ca-app-pub-1510165203415209/3497390015",on_load)    # Provide interstitial ad id

def showAd():
	app.showInterstitialAd(on_success)    # Provide interstitial ad id

root = Root("Home",bgColor="#202020")
lay = FlexLayout(width="100vw", height="100vh", alignItems="center", justify="center", rowGap="200px", direction="column")
load = Button(text="Load Ad", onClick=loadAd, bgColor="#3f48cc", width="150px")
show = Button(text="Show Ad", onClick=showAd, bgColor="cyan", fontColor="black", width="150px")

lay.add(load)
lay.add(show)

root.add(lay)  
root.run()