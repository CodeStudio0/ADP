from jnius import autoclass

activity = autoclass("org.kivy.android.PythonActivity").mActivity
loc = activity.getFilesDir().toString()

class AdMob:
	def __init__(self,val):
		if(activity.ads):
			self.app = activity.ads
		elif(val != ""):
			self.app = val
		else:
			activity.toast("Invalid id")
		f = open(loc+"/ads-id.txt","w")
		f.write(val)
		f.close()
	def loadRewardedAd(self,val):
		if(activity.ads):
			activity.loadRewardedAd("")
		elif(val != ""):
			activity.loadRewardedAd(val)
		else:
			activity.toast("Invalid unit")
	def showRewardedAd(self):
		return activity.showRewardedAd()
	def loadInterstitialAd(self,val):
		if(activity.ads):
			activity.loadInterstitialAd("")
		elif(val != ""):
			activity.loadInterstitialAd(val)
		else:
			activity.toast("Invalid unit")
	def showInterstitialAd(self):
		return activity.showInterstitialAd()