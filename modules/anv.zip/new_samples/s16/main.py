import ctypes, sys

import math, fractions
if not hasattr(fractions, "gcd"):
    fractions.gcd = math.gcd  # patch for VisPy
# --- Patch ctypes.util for Android ---
try:
    import ctypes.util
except ImportError:
    import types
    ctypes.util = types.SimpleNamespace()

if not hasattr(ctypes.util, "find_library"):
    def find_library(name):
        if name.lower() in ("sdl2",):
            return "libSDL2.so"
        if name.lower() in ("glesv2", "gles2"):
            return "libGLESv2.so"
        return None
    ctypes.util.find_library = find_library
    sys.modules["ctypes.util"] = ctypes.util

# --- VisPy imports ---

# Force SDL2 backend

# Simple shader
import vispy
from vispy import scene, app
#from vispy.visuals.filters import ShadingFilter
app.use_app("sdl2")
import trimesh   # pip install trimesh

# Load .obj file
mesh_data = trimesh.load("teapot.obj")   # replace with your path

# Extract vertices and faces
vertices = np.array(mesh_data.vertices, dtype=np.float32)
faces = np.array(mesh_data.faces, dtype=np.uint32)

# Create a canvas
canvas = scene.SceneCanvas(show=True)
view = canvas.central_widget.add_view()

# Create mesh visual
mesh = scene.visuals.Mesh(vertices=vertices, faces=faces,
                          color=(0.5, 0.7, 1, 1),  # light blue
                          parent=view.scene, shading="flat")

#shading = ShadingFilter(shading='smooth', lights='directional')
#mesh.attach(shading)

# Add a wireframe overlay
wireframe = scene.visuals.Mesh(vertices=vertices, faces=faces,
                               color='black', mode='lines',
                               parent=view.scene)

view.camera = 'turntable'

@canvas.events.key_press.connect
def on_key_pressed(event):
    sys.exit(0)

if __name__ == '__main__':
    app.run()
























