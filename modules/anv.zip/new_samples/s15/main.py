import os
os.environ["PYOPENGL_PLATFORM"] = "egl"

import sys, ctypes
import sdl2
from OpenGL import GLES2 as gl   # OpenGL ES 2.0 bindings

# Vertex Shader (GLSL ES 2.0)
VERTEX_SHADER_SRC = """
attribute vec3 a_position;
attribute vec3 a_color;
varying vec3 v_color;
void main() {
    gl_Position = vec4(a_position, 1.0);
    v_color = a_color;
}
"""

# Fragment Shader
FRAGMENT_SHADER_SRC = """
precision mediump float;
varying vec3 v_color;
void main() {
    gl_FragColor = vec4(v_color, 1.0);
}
"""

def compile_shader(source, shader_type):
    shader = gl.glCreateShader(shader_type)
    gl.glShaderSource(shader, source)
    gl.glCompileShader(shader)

    # Check compile status
    status = gl.glGetShaderiv(shader, gl.GL_COMPILE_STATUS)
    if not status:
        log = gl.glGetShaderInfoLog(shader).decode()
        raise RuntimeError(f"Shader compile error: {log}")
    return shader

def create_program(vs_source, fs_source):
    vs = compile_shader(vs_source, gl.GL_VERTEX_SHADER)
    fs = compile_shader(fs_source, gl.GL_FRAGMENT_SHADER)

    program = gl.glCreateProgram()
    gl.glAttachShader(program, vs)
    gl.glAttachShader(program, fs)
    gl.glLinkProgram(program)

    # Check link status
    status = gl.glGetProgramiv(program, gl.GL_LINK_STATUS)
    if not status:
        log = gl.glGetProgramInfoLog(program).decode()
        raise RuntimeError(f"Program link error: {log}")
    return program

def main():
    # Init SDL2 video with OpenGL ES 2.0
    sdl2.SDL_Init(sdl2.SDL_INIT_VIDEO)
    sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_CONTEXT_PROFILE_MASK,
                             sdl2.SDL_GL_CONTEXT_PROFILE_ES)
    sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_CONTEXT_MAJOR_VERSION, 2)
    sdl2.SDL_GL_SetAttribute(sdl2.SDL_GL_CONTEXT_MINOR_VERSION, 0)

    window = sdl2.SDL_CreateWindow(
        b"PySDL2 + GLES2 Triangle",
        sdl2.SDL_WINDOWPOS_CENTERED, sdl2.SDL_WINDOWPOS_CENTERED,
        300, 480, sdl2.SDL_WINDOW_OPENGL | sdl2.SDL_WINDOW_SHOWN
    )
    glcontext = sdl2.SDL_GL_CreateContext(window)
    sdl2.SDL_GL_SetSwapInterval(1)  # vsync

    # Create shader program
    program = create_program(VERTEX_SHADER_SRC, FRAGMENT_SHADER_SRC)
    gl.glUseProgram(program)

    # Triangle vertex data (x, y, z, r, g, b)
    vertices = [
        # Position        # Color
        0.0,  0.5, 0.0,   1.0, 0.0, 0.0,  # top (red)
       -0.5, -0.5, 0.0,   0.0, 1.0, 0.0,  # left (green)
        0.5, -0.5, 0.0,   0.0, 0.0, 1.0   # right (blue)
    ]
    vertices = (ctypes.c_float * len(vertices))(*vertices)

    # Create VBO
    vbo = gl.glGenBuffers(1)
    gl.glBindBuffer(gl.GL_ARRAY_BUFFER, vbo)
    gl.glBufferData(gl.GL_ARRAY_BUFFER, ctypes.sizeof(vertices), vertices, gl.GL_STATIC_DRAW)

    # Locate attributes
    pos_loc = gl.glGetAttribLocation(program, "a_position")
    col_loc = gl.glGetAttribLocation(program, "a_color")

    stride = 6 * ctypes.sizeof(ctypes.c_float)
    gl.glEnableVertexAttribArray(pos_loc)
    gl.glVertexAttribPointer(pos_loc, 3, gl.GL_FLOAT, False, stride, ctypes.c_void_p(0))
    gl.glEnableVertexAttribArray(col_loc)
    gl.glVertexAttribPointer(col_loc, 3, gl.GL_FLOAT, False, stride, ctypes.c_void_p(12))

    # Main loop
    event = sdl2.SDL_Event()
    running = True
    while running:
        while sdl2.SDL_PollEvent(ctypes.byref(event)):
            if event.type == sdl2.SDL_QUIT or event.type == sdl2.SDL_KEYDOWN:
                running = False

        # Clear
        gl.glClearColor(0.1, 0.1, 0.2, 1.0)
        gl.glClear(gl.GL_COLOR_BUFFER_BIT)

        # Draw triangle
        gl.glDrawArrays(gl.GL_TRIANGLES, 0, 3)

        # Swap buffers
        sdl2.SDL_GL_SwapWindow(window)

    # Cleanup
    gl.glDeleteBuffers(1, [vbo])
    sdl2.SDL_GL_DeleteContext(glcontext)
    sdl2.SDL_DestroyWindow(window)
    sdl2.SDL_Quit()

if __name__ == "__main__":
    sys.exit(main())
























