# DOOM-style-3D-Game-Engine-in-Python-and-Kivy-On-Android
DOOM-style 3D Game Engine in Python and Kivy On Android

Read Me!
This project is written on an Android tablet using a very basic IDE. There is no syntax highligthing, expect uneven spaces, and many more pep 8 non-compliant arrangements. :)

(I will try to a install linux distro on this tablet so I can get a better IDE!)
