from kivy.app import App
from kivy_garden.mapview import MapView, MapMarker
from kivy.core.window import Window
from kivy.uix.boxlayout import BoxLayout
import sys

class MapRoot(BoxLayout):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        # Set initial latitude and longitude
        lat, lon = 20.350739, 85.806301  # Example: New Delhi, India

        # Create MapView
        mapview = MapView(zoom=10, lat=lat, lon=lon)
        self.add_widget(mapview)

        # Add a marker
        marker = MapMarker(lat=lat, lon=lon, source="marker.png")  # optional custom marker image
        mapview.add_widget(marker)

class MapApp(App):
    
    def back(self, window, key, *args):
        if key == 27:
            sys.exit(0)
    
    def build(self):
        Window.bind(on_keyboard=self.back)
        return MapRoot()

if __name__ == "__main__":
    MapApp().run()
























