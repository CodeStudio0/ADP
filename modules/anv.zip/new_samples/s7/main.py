from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.togglebutton import ToggleButton
from kivy.uix.label import Label
from kivy.uix.image import Image
from kivy.core.window import Window
from android.permissions import request_permissions,check_permission,Permission
import cv2, sys
import camera
# importing built-in module
class CameraApp(App):
    def cam_update(self, frame):
        frame = cv2.Canny(frame, 50, 150)
        return frame
    
    def back(self, window, key, *args):
        if key == 27:
            sys.exit(0)
    
    def build(self):
        self.invert = False
        self.gray = False
        self.front = False
        self.edge = False
        Window.bind(on_keyboard=self.back)
        box = BoxLayout(orientation='vertical')
        if not check_permission('android.permission.CAMERA'):
            request_permissions([Permission.CAMERA])
            return Label(text="Restart app after providing camera permission")
        self.cam = camera(play=True,allow_stretch=True,keep_ratio=True)
        box.add_widget(self.cam)
        return box

if __name__ == "__main__":
	CameraApp().run()
























