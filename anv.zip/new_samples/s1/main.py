from crysta import Root, Button, SidePanel, Layout, TextView, FlexLayout, FlexLayout, ZapButton, Chips, Input, InputOutline, Radio, Check, ListView, Menu, Progress, ProgressMeter, ProgressIndicator, Dialog
import core

side = None
def start():
    navigate(0)

root = Root("Home", bgColor="#121212")
banner = FlexLayout(width="100%",inset=["10px"],boxSizing="border-box",alignItems="center",justify="space-between",margin=["30px","0"])
bar = FlexLayout(width="100%",boxSizing="border-box",alignItems="center")
menu = Button(vibrate=0,iconSize="22px",icon="menu",bgColor="transparent",iconColor="#cccccc",rippleColor="transparent",onClick=lambda: side.show())
bar.add(menu)
bar.add(TextView(text="Crysta UI",bgColor="transparent",iconColor="#cccccc",fontSize="20px",fontColor="#cccccc",margin=["0px","5px"],letterSpacing="1px"))
banner.add(bar)
share = Button(vibrate=0,iconSize="22px",icon="share",bgColor="transparent",iconColor="#cccccc",onClick=lambda: core.shareText("🚀 Build powerful Python apps on Android in seconds with AnvPy – now on Google Play! 👉 https://play.google.com/store/apps/details?id=org.python.adp"))
banner.add(share)
root.add(banner)
main = Layout(width="100vw", height="80vh")
main.setStyle(overflow="hidden")
side = SidePanel(bgColor="#1e1c1c", boxSizing="border-box", padding="32px 0")

def navigate(index):
    flex = None
    box = None
    screen = None
    point = None
    global main
    main.setAttribute(attrib="innerHTML",value="")
    if index == 0:
        flex = FlexLayout(width="100%",height="90vh",alignItems="center",justify="flex-start",margin=["0px","0"],direction="column",rowGap="100px")
        btn = Button(vibrate=0,bgColor="#a68c94",iconSize="25px",text="Hello Android",margin=["100px","0","0"],fontColor="black",rippleColor="#333333",fontSize="14px")
        flex.add(btn)
        btn = Button(vibrate=0,icon="android",text="Hello Android",bgColor="transparent",fontColor="#a68c94",radius=["5px"],border="2px solid #a68c94",rippleColor="#a68c94",fontSize="14px")
        flex.add(btn)
        layout = Layout(bgColor="#735961",width="fit-content",radius=["10px"])
        button = Button(vibrate=0,text="Click Me !",bgColor="#a68c94",radius=["10px"],transform="translateY(-5px)",fontColor="black", fontSize="14px")
        layout.add(button)
        flex.add(layout)
        btn = None
        clk = False
        def show():
            nonlocal clk
            if(not clk):
                clk = True
                btn.setStyle(transform="rotate(90deg)")
                btn.setAttribute(attrib="innerHTML",value="close",child=[0])
                for i in range(3):
                    flex.setStyle(transform="scale(1)",opacity=1,child=[4 + i])
            else:
                clk = False
                btn.setStyle(transform="rotate(0deg)")
                btn.setAttribute(attrib="innerHTML",value="link",child=[0])
                for i in range(3):
                    flex.setStyle(transform="scale(.8)",opacity=0,child=[4 + i])

        btn = ZapButton(icon="link",bgColor="#a68c94",radius=["100%"],width="60px",height="60px",bottom="15vh",fontWeight="bold",transition=".5s ease",rippleColor="transparent",onClick=show)
        flex.add(btn)
        flex.add(ZapButton(icon="mail",bgColor="#bca9af",radius=["100%"],bottom="28vh",right="25px",fontWeight="bold",transition=".5s ease",transform="scale(0.8)",opacity=0,rippleColor="transparent"))
        flex.add(ZapButton(icon="message",bgColor="#bca9af",radius=["100%"],bottom="37vh",right="25px",fontWeight="bold",transition=".5s ease",transform="scale(0.8)",opacity=0,rippleColor="transparent"))
        flex.add(ZapButton(icon="content_copy",bgColor="#bca9af",radius=["100%"],bottom="46vh",right="25px",fontWeight="bold",transition=".5s ease",transform="scale(0.8)",opacity=0,rippleColor="transparent"))
    elif index == 1:
        flex = FlexLayout(width="100%",height="90vh",alignItems="center",justify="flex-start",margin=["0px","0"],direction="column",rowGap="100px")
        box = FlexLayout(width="80vw",position='relative',margin=["100px","10vw","0"],bgColor="transparent",radius=["10px"],inset=["5px"],alignItems='center')
        def traverse(x):
            screen.setStyle(left=str(x) + "px")

        dt = ["Xbox","Disney","Sony"]
        for i in dt:
            btn = Button(vibrate=0,text=i,bgColor="transparent",fontColor="white",flex=1,rippleColor="transparent")
            btn.bind("click",lambda b=btn: b.getAttribute("offsetLeft",callback=traverse))
            box.add(btn)
        flex.add(box)

        chips = Chips(items=["Technology","Business","Education","Health","Entertainment","Finance","Gaming","Lifestyle","Travel","Science"],iconSize="16px",bgColorActive="#a68c94",fontColorNormal="#e0e0e0",fontColorActive="black",width="100vw",wrap=0,padding="20px",margin=[],boxSizing="border-box")
        flex.add(chips)
    elif index == 2:
        flex = FlexLayout(width="100%",height="90vh",alignItems="center",justify="flex-start",margin=["0px","0"],direction="column",rowGap="150px")
        inp = Input(hint="Name",activeColor="#a68c94",margin=["100px","0","0"],fontColor="#cccccc",inactiveColor="#cccccc",hintColor="#cccccc",textColor="white")
        psw = InputOutline(hint="Password",activeColor="#a68c94",fontColor="#cccccc",inactiveColor="#cccccc",hintColor="#cccccc",icon="visibility_off",hintBg="#121212",textColor="white")
        psw.setStyle(webkitTextSecurity="disc",child=[0])
        flex.add(inp)
        flex.add(psw)
    elif index == 3:
        flex = FlexLayout(width="100%",height="90vh",alignItems="center",justify="flex-start",margin=["0px","0"],direction="column",rowGap="100px")
        mn = FlexLayout(direction="column",rowGap="20px",margin=["100px","0","0"])
        box = FlexLayout(colGap="20px")
        box.add(Radio(group="1",activeColor="#a68c94",inactiveColor="#cccccc"))
        box.add(TextView(text="Sony",fontColor="#cccccc"))
        mn.add(box)
        box = FlexLayout(colGap="20px")
        box.add(Radio(group="1",activeColor="#a68c94",inactiveColor="#cccccc"))
        box.add(TextView(text="Disney",fontColor="#cccccc"))
        mn.add(box)
        box = FlexLayout(colGap="20px")
        box.add(Radio(group="1",activeColor="#a68c94",inactiveColor="#cccccc"))
        box.add(TextView(text="Xbox",fontColor="#cccccc"))
        mn.add(box)
        flex.add(mn)
        check = Check(activeColor="#a68c94",inactiveColor="#cccccc",iconColor="#121212")
        flex.add(check)
    elif index == 4:
        flex = FlexLayout(width="100%",height="100vh",alignItems="center",justify="center",margin=["0px","0"],direction="column",rowGap="100px")
        dialog = Dialog(title="Basic Dialog",text="A dialog is a modal window that appears infront of app content to provide basical information or ask for a decision",positiveText="SEND",negativeText="CANCEL",bgColor="#333333",textColor="#cccccc",titleColor="white",btnColor="#a68c94")
        btn = Button(vibrate=0,bgColor="#a68c94",iconSize="25px",text="Show Dialog",radius=["5px"],fontColor="black",fontSize="14px",onClick=lambda: dialog.show())
        flex.add(btn)
        flex.add(dialog)
    elif index == 5:
        flex = FlexLayout(width="100%",height="90vh",alignItems="center",justify="flex-start",margin=["0px","0"],direction="column",rowGap="100px")
        box = FlexLayout(width="100%",bgColor="#202020",alignItems="center",justify="space-around",inset=["15px","20px","50px"],boxSizing="border-box",position="absolute",bottom="0px")
        elm = 0
        def nav(i,x):
            nonlocal elm
            nonlocal point
            if elm != i:
                box.setStyle(transform="",child=[elm])
                box.setStyle(color="#cccccc",child=[elm,0])
                box.setStyle(transform="translateY(-5px) scale(1.1)",child=[i])
                box.setStyle(color="white",child=[i,0])
                elm = i
            point.setStyle(left=str(int(x) + 20) + "px")
        dt = ["home","search","shopping_cart","account_circle"]
        for n,i in enumerate(dt):
            btn = None
            if n == 0:
                btn = Button(vibrate=0,icon=i,bgColor="transparent",iconSize="25px",transition=".5s ease",rippleColor="transparent",transform="translateY(-5px) scale(1.1)")
            else:
                btn = Button(vibrate=0,icon=i,bgColor="transparent",iconSize="25px",transition=".5s ease",rippleColor="transparent")
            btn.bind("click",lambda b=btn, index=n: b.getAttribute("offsetLeft", lambda x: nav(index, x)))
            box.add(btn)
        flex.add(box)
        btn = Button(vibrate=0,bgColor="#a68c94",iconSize="25px",text="Open Navigation",radius=["5px"],fontColor="black",margin=["200px","0"],onClick=lambda: side.show())
        flex.add(btn)

    elif index == 6:
        flex = FlexLayout(width="100%",height="90vh",alignItems="center",justify="flex-start",margin=["0px","0"],direction="column",rowGap="100px",inset=["0","10px"],boxSizing="border-box")
        progress = Progress(percent=65,margin=["150px","0"],width="70vw",bgColor="#735961",barColor="#a68c94")
        flex.add(progress)
        meter = ProgressMeter(percent=0,margin=["0","0"],width="70vw",barColor="#202020",nodeColor="cyan")
        flex.add(meter)

    elif index == 7:
        flex = FlexLayout(width="100%",height="90vh",alignItems="center",justify="flex-start",margin=["0px","0"],direction="column",rowGap="100px",inset=["0","10px"],boxSizing="border-box")
        box = FlexLayout(width="30vw",height="30vw",bgColor="white",margin=["150px","35vw"],radius=["100%"],boxShadow="0 5px 8px black",position="relative",zIndex="2",alignItems="center",justify="center")
        heart = Layout(width="15vw",height="15vw",img="heart.png",filter="brightness(0)",opacity=".8")
        box.add(heart)
        flex.add(box)
    else:
        flex = FlexLayout(width="100%",height="100vh",alignItems="center",justify="flex-start",margin=["0px","0px"],direction="column",rowGap="50px",inset=["0","10px"],boxSizing="border-box")
        flex.add(TextView(text="This is a challenge for all, checkout the previous showcase and try to code the heart box by yourself and upload it here.",margin=["100px","5vw","0px"],color="#cccccc",width="90vw",textAlign="center",fontSize="14px"))
        flex.add(Button(text="UPLOAD HERE",margin=["0px","0"],bgColor="#3f48cc",inset=["10px","15px"],radius=["5px"],onClick=lambda: core.link("https://t.me/andropython")))


    main.add(flex)
    if(index == 1):
        dm = [0]
        def scr(w,h):
            nonlocal screen
            screen = Layout(opacity='0.3',left=0,transition='.5s ease',position='absolute',radius=["15px"],bgColor="#a68c94",height=str(h) + "px",width=str(w) + "px")
            box.add(screen)
        def getWidth():
            box.getAttribute("offsetWidth",callback=lambda w: getHeight(w),child=[0])
        def getHeight(w):
            box.getAttribute("offsetHeight",callback=lambda h: scr(w,h),child=[0])
        getWidth()
    elif(index == 5):
        dm = [0]
        def pnt(l,t):
            nonlocal point
            point = Layout(width="10px",height="10px",bgColor="#a68c94",radius=["100%"],transition=".5s ease",position="absolute",left=str(int(l) + 20) + "px",top=str(int(t) + 45) + "px")
            box.add(point)
        def getLeft():
            box.getAttribute("offsetLeft",callback=lambda l: getTop(l),child=[0])
        def getTop(l):
            box.getAttribute("offsetTop",callback=lambda t: pnt(l,t),child=[0])
        getLeft()

side.add(TextView(text="Widgets", fontColor="white", icon="extension", fontSize="16px",
         iconSize="15px", margin=["20px", "30px", "0px"], letterSpacing="1px"))
side.add(TextView(text="Basic",margin=["30px","30px","0px"],fontColor="#e6e6e6",letterSpacing="1px"))
l1 = Layout()
l2 = Layout()

elm = 0
def mode(val):
    global elm
    l1.setStyle(background="transparent",child=[elm])
    l2.setStyle(background="transparent",child=[0])
    l1.setStyle(background="#58444a",child=[val])
    navigate(val)
    elm = val

def mode2():
    global elm
    l1.setStyle(background="transparent",child=[elm])
    l2.setStyle(background="#58444a",child=[0])
    navigate(8)

ub = [["Buttons","circle"],["Segmented Controls","spoke"],["Input","power_input"],["Form Controls","adjust"],["Dialogs","chat_bubble"],["Navigation Bars","navigation"],["Progress Bars","speed"]]
for n,i in enumerate(ub):
    bg = None
    if n == 0:
        bg = "#58444a"
    else:
        bg = "transparent"
    btn = Button(text=i[0],fontColor="#cccccc",icon=i[1],fontSize="16px",iconSize="14px",margin=["15px","10px","5px"],bgColor=bg,width="90%",rippleColor="transparent",justifyContent="flex-start",transition=".5s ease",letterSpacing=".5px",vibrate=0)
    btn.bind("click",lambda i=n: mode(i))
    l1.add(btn)
side.add(l1)
side.add(Layout(width="90%",height="2px",bgColor="#999999",margin=["20px","15px"]))
side.add(TextView(text="Advanced",margin=["25px","30px","0px"],fontColor="#e6e6e6",letterSpacing="1px"))
lb = [["Heart Box","favorite"]]
for n,i in enumerate(lb):
    bg = "transparent"
    btn = Button(text=i[0],fontColor="#cccccc",icon=i[1],fontSize="16px",iconSize="14px",margin=["15px","10px","5px"],bgColor=bg,width="90%",rippleColor="transparent",justifyContent="flex-start",transition=".5s ease",letterSpacing=".5px",vibrate=0)
    btn.bind("click",lambda: mode2())
    l2.add(btn)

side.add(l2)
root.add(side)
root.add(main)
root.onStart(start)
root.run()
























