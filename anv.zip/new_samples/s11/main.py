from kivy.app import App
from kivy.uix.label import Label
from kivy.core.window import Window
import sys
import seaborn as sns
import matplotlib.pyplot as plt
import pandas as pd
from core import anv

class MainApp(App):
    def back(self, window, key, *args):
        if key == 27:
            sys.exit(0)
    def build(self):
        Window.bind(on_keyboard=self.back)
        sns.set_theme(style="whitegrid")
        anv.set_orientation("landscape")
        diamonds = pd.read_csv("diamonds.csv")
        f, ax = plt.subplots(figsize=(6.5, 6.5))
        sns.despine(f, left=True, bottom=True)
        clarity_ranking = ["I1", "SI2", "SI1", "VS2", "VS1", "VVS2", "VVS1", "IF"]
        sns.scatterplot(x="carat", y="price",
                hue="clarity", size="depth",
                palette="ch:r=-.2,d=.3_r",
                hue_order=clarity_ranking,
                sizes=(1, 8), linewidth=0,
                data=diamonds, ax=ax)
        # show the image in a screen
        anv.pltshow(plt)
        return Label(text="")

MainApp().run()
























